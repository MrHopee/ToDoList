import psycopg2

try:
    conn = psycopg2.connect(
        host="localhost",
        database="ToDoList",
        user="postgres",
        password="umut123")

    print("connection successful")

    # Create a cursor to perform database operations
    cursor = conn.cursor()
    # Executing a SQL query
    cursor.execute("SELECT version();")
    # Fetch result
    record = cursor.fetchone()
    print("You are connected to - ", record, "\n")

except:
    print("connection unsuccessful")


    #     if conn == null or conn.isClosed() :
    #         psycopg2.connect(
    #         host="localhost",
    #         database="ToDoList",
    #         user="postgres",
    #         password="umut123")
    #
    #     return conn;
    # }